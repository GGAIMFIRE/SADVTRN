import { useState, useEffect } from "react";
import {
  Plus,
  Copy,
  Trash2,
  CheckCircle,
  AlertCircle,
  TrendingUp,
  Activity,
  Zap as ZapIcon,
} from "lucide-react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { Sidebar } from "./components/Sidebar";
import { Card, CardHeader, CardContent, CardTitle } from "./components/Card";
import { StatCard } from "./components/StatCard";

interface BotStats {
  users: number;
  automations: number;
  messages: number;
  uptime: string;
  bots: number;
  webhooks: number;
}

interface Bot {
  id: string;
  token: string;
  connected: boolean;
  createdAt: string;
}

interface Automation {
  id: string;
  name: string;
  trigger: string;
  action: string;
  botId: string;
  enabled: boolean;
}

export default function App() {
  const [stats, setStats] = useState<BotStats | null>(null);
  const [darkMode, setDarkMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [currentPage, setCurrentPage] = useState("dashboard");
  const [bots, setBots] = useState<Bot[]>([]);
  const [automations, setAutomations] = useState<Automation[]>([]);
  const [logs, setLogs] = useState<string[]>([]);
  const [telegramToken, setTelegramToken] = useState("");
  const [autoName, setAutoName] = useState("");
  const [autoTrigger, setAutoTrigger] = useState("");
  const [autoAction, setAutoAction] = useState("");

  // Chart data mock
  const chartData = [
    { name: "Jan", users: 40, messages: 24, automations: 10 },
    { name: "Fev", users: 45, messages: 30, automations: 12 },
    { name: "Mar", users: 50, messages: 35, automations: 15 },
    { name: "Abr", users: 58, messages: 42, automations: 18 },
    { name: "Mai", users: 65, messages: 48, automations: 22 },
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      fetch("/api/stats")
        .then((res) => res.json())
        .then(setStats)
        .catch((err) => console.error(err));

      fetch("/api/bots")
        .then((res) => res.json())
        .then(setBots)
        .catch((err) => console.error(err));

      fetch("/api/automations")
        .then((res) => res.json())
        .then(setAutomations)
        .catch((err) => console.error(err));

      fetch("/api/logs?limit=20")
        .then((res) => res.json())
        .then(setLogs)
        .catch((err) => console.error(err));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const handleConnectBot = async () => {
    if (!telegramToken.trim()) return;

    const res = await fetch("/api/bot/connect", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token: telegramToken }),
    });

    const data = await res.json();
    if (data.success) {
      setTelegramToken("");
    }
  };

  const handleAddAutomation = async () => {
    if (!autoName || !autoTrigger || !autoAction || bots.length === 0) return;

    await fetch("/api/automations", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: autoName,
        trigger: autoTrigger,
        action: autoAction,
        botId: bots[0]?.id || "",
      }),
    });

    setAutoName("");
    setAutoTrigger("");
    setAutoAction("");
  };

  const handleDeleteBot = async (botId: string) => {
    await fetch(`/api/bot/${botId}`, { method: "DELETE" });
  };

  const handleCopyToken = (token: string) => {
    navigator.clipboard.writeText(token);
  };

  const bgClass = darkMode ? "dark bg-gray-900 text-white" : "bg-gray-50 text-gray-900";

  return (
    <div className={`${bgClass} min-h-screen transition-colors`}>
      <div className="flex h-screen">
        <Sidebar
          open={sidebarOpen}
          onToggle={() => setSidebarOpen(!sidebarOpen)}
          darkMode={darkMode}
          onDarkModeToggle={() => setDarkMode(!darkMode)}
          currentPage={currentPage}
          onPageChange={setCurrentPage}
        />

        {/* Main Content */}
        <div className="flex-1 overflow-auto bg-gray-50 dark:bg-gray-900">
          {/* Header */}
          <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-8 py-6">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
              {currentPage === "dashboard" && "📊 Dashboard"}
              {currentPage === "bot" && "🤖 Gerenciador de Bots"}
              {currentPage === "automations" && "⚙️ Automações"}
              {currentPage === "settings" && "⚙️ Configurações"}
            </h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              {currentPage === "dashboard" && "Visualize métricas e estatísticas do sistema"}
              {currentPage === "bot" && "Gerencie seus bots Telegram conectados"}
              {currentPage === "automations" && "Crie e gerencie automações inteligentes"}
              {currentPage === "settings" && "Configure webhooks e preferências"}
            </p>
          </div>

          {/* Content */}
          <div className="p-8">
            {currentPage === "dashboard" && (
              <div className="space-y-8">
                {/* Stats Cards */}
                {stats && (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <StatCard
                      label="Total de Usuários"
                      value={stats.users}
                      icon="👥"
                      trend="+12% neste mês"
                      color="blue"
                    />
                    <StatCard
                      label="Automações Ativas"
                      value={stats.automations}
                      icon="⚙️"
                      trend="3 novas"
                      color="purple"
                    />
                    <StatCard
                      label="Bots Conectados"
                      value={stats.bots}
                      icon="🤖"
                      color="green"
                    />
                    <StatCard
                      label="Webhooks"
                      value={stats.webhooks}
                      icon="🔗"
                      color="orange"
                    />
                  </div>
                )}

                {/* Charts */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Crescimento de Usuários</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={chartData}>
                          <CartesianGrid stroke="#e5e7eb" />
                          <XAxis stroke="#9ca3af" />
                          <YAxis stroke="#9ca3af" />
                          <Tooltip />
                          <Legend />
                          <Line
                            type="monotone"
                            dataKey="users"
                            stroke="#3b82f6"
                            strokeWidth={2}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Distribuição de Atividades</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={chartData}>
                          <CartesianGrid stroke="#e5e7eb" />
                          <XAxis stroke="#9ca3af" />
                          <YAxis stroke="#9ca3af" />
                          <Tooltip />
                          <Legend />
                          <Bar dataKey="messages" fill="#8b5cf6" />
                          <Bar dataKey="automations" fill="#10b981" />
                        </BarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                </div>

                {/* Activity Status */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Activity size={20} /> Status do Sistema
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {[
                        {
                          label: "Servidor Express",
                          status: "Online",
                          color: "green",
                        },
                        {
                          label: "Bot Telegram",
                          status: "Aguardando",
                          color: "yellow",
                        },
                        { label: "Banco de Dados", status: "Conectado", color: "green" },
                      ].map((item, i) => (
                        <div
                          key={i}
                          className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg"
                        >
                          <span className="font-medium">{item.label}</span>
                          <span
                            className={`px-3 py-1 rounded-full text-white text-sm font-medium ${
                              item.color === "green"
                                ? "bg-green-500"
                                : item.color === "yellow"
                                  ? "bg-yellow-500"
                                  : "bg-red-500"
                            }`}
                          >
                            {item.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {currentPage === "bot" && (
              <div className="space-y-6">
                {/* New Bot Card */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Plus size={20} /> Conectar Novo Bot
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="max-w-md space-y-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Token do BotFather
                        </label>
                        <input
                          type="password"
                          placeholder="Seu token seguro aqui"
                          value={telegramToken}
                          onChange={(e) => setTelegramToken(e.target.value)}
                          className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <button
                        onClick={handleConnectBot}
                        className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white py-3 rounded-lg transition font-medium flex items-center justify-center gap-2"
                      >
                        <ZapIcon size={18} /> Conectar Bot
                      </button>
                    </div>
                  </CardContent>
                </Card>

                {/* Bots List */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">
                    Bots Conectados ({bots.length})
                  </h3>
                  {bots.length === 0 ? (
                    <Card>
                      <CardContent className="text-center py-12">
                        <AlertCircle className="mx-auto mb-4 text-gray-400" size={48} />
                        <p className="text-gray-500 dark:text-gray-400">
                          Nenhum bot conectado ainda
                        </p>
                      </CardContent>
                    </Card>
                  ) : (
                    <div className="grid gap-4">
                      {bots.map((bot) => (
                        <Card key={bot.id}>
                          <CardContent className="py-4">
                            <div className="flex items-center justify-between">
                              <div className="flex-1">
                                <p className="font-semibold flex items-center gap-2">
                                  <CheckCircle className="text-green-500" size={18} />{" "}
                                  {bot.id}
                                </p>
                                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                                  {bot.token.substring(0, 30)}...
                                </p>
                              </div>
                              <div className="flex gap-2">
                                <button
                                  onClick={() => handleCopyToken(bot.token)}
                                  className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition"
                                >
                                  <Copy size={18} />
                                </button>
                                <button
                                  onClick={() => handleDeleteBot(bot.id)}
                                  className="p-2 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/20 hover:text-red-500 transition"
                                >
                                  <Trash2 size={18} />
                                </button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {currentPage === "automations" && (
              <div className="space-y-6">
                {bots.length === 0 ? (
                  <Card>
                    <CardContent className="text-center py-12">
                      <AlertCircle className="mx-auto mb-4 text-gray-400" size={48} />
                      <p className="text-gray-500 dark:text-gray-400">
                        Conecte um bot primeiro para criar automações
                      </p>
                    </CardContent>
                  </Card>
                ) : (
                  <>
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Plus size={20} /> Criar Automação
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="max-w-2xl space-y-4">
                          <input
                            type="text"
                            placeholder="Nome da automação"
                            value={autoName}
                            onChange={(e) => setAutoName(e.target.value)}
                            className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                          <input
                            type="text"
                            placeholder="Trigger (ex: /start, /help)"
                            value={autoTrigger}
                            onChange={(e) => setAutoTrigger(e.target.value)}
                            className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                          <input
                            type="text"
                            placeholder="Ação (ex: enviar mensagem)"
                            value={autoAction}
                            onChange={(e) => setAutoAction(e.target.value)}
                            className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                          <button
                            onClick={handleAddAutomation}
                            className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white py-3 rounded-lg transition font-medium"
                          >
                            <Plus className="inline mr-2" size={18} /> Criar Automação
                          </button>
                        </div>
                      </CardContent>
                    </Card>

                    <div>
                      <h3 className="text-lg font-semibold mb-4">
                        Automações Ativas ({automations.length})
                      </h3>
                      <div className="grid gap-4">
                        {automations.map((auto) => (
                          <Card key={auto.id}>
                            <CardContent className="py-4">
                              <div>
                                <p className="font-semibold text-lg">{auto.name}</p>
                                <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
                                  {auto.trigger} → {auto.action}
                                </p>
                                <p className="text-xs text-gray-400 mt-2">ID: {auto.id}</p>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </div>
            )}

            {currentPage === "settings" && (
              <Card>
                <CardHeader>
                  <CardTitle>Configurações do Sistema</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="max-w-2xl space-y-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Webhook URL
                      </label>
                      <input
                        type="text"
                        placeholder="https://seu-dominio.com/api/webhook"
                        className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Timeout (segundos)
                      </label>
                      <input
                        type="number"
                        defaultValue="30"
                        className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700"
                      />
                    </div>
                    <button className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white px-6 py-3 rounded-lg transition font-medium">
                      Salvar Configurações
                    </button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
