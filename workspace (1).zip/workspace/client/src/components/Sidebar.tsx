import { BarChart3, Zap, MessageSquare, Settings, Moon, Sun, Menu, X } from "lucide-react";

interface SidebarProps {
  open: boolean;
  onToggle: () => void;
  darkMode: boolean;
  onDarkModeToggle: () => void;
  currentPage: string;
  onPageChange: (page: string) => void;
}

const menuItems = [
  { id: "dashboard", icon: BarChart3, label: "Dashboard" },
  { id: "bot", icon: Zap, label: "Bots" },
  { id: "automations", icon: MessageSquare, label: "Automações" },
  { id: "settings", icon: Settings, label: "Configurações" },
];

export function Sidebar({
  open,
  onToggle,
  darkMode,
  onDarkModeToggle,
  currentPage,
  onPageChange,
}: SidebarProps) {
  return (
    <div
      className={`${
        open ? "w-72" : "w-20"
      } bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-900 border-r border-gray-200 dark:border-gray-700 transition-all duration-300 flex flex-col h-screen`}
    >
      {/* Logo */}
      <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
        {open && (
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">GG</span>
            </div>
            <div>
              <h1 className="font-bold text-lg text-gray-900 dark:text-white">GG Bot</h1>
              <p className="text-xs text-gray-500 dark:text-gray-400">v2.0</p>
            </div>
          </div>
        )}
        <button onClick={onToggle} className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg">
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Menu */}
      <nav className="flex-1 p-4 space-y-2">
        {menuItems.map(({ id, icon: Icon, label }) => (
          <button
            key={id}
            onClick={() => onPageChange(id)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
              currentPage === id
                ? "bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg"
                : "text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700"
            }`}
          >
            <Icon size={20} />
            {open && <span className="font-medium">{label}</span>}
          </button>
        ))}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-gray-200 dark:border-gray-700 space-y-2">
        <button
          onClick={onDarkModeToggle}
          className="w-full flex items-center gap-3 px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg transition"
        >
          {darkMode ? <Sun size={20} /> : <Moon size={20} />}
          {open && <span>{darkMode ? "Modo Claro" : "Modo Escuro"}</span>}
        </button>
      </div>
    </div>
  );
}
