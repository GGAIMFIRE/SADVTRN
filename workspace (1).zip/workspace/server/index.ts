import express, { Request, Response } from "express";
import path from "path";
import { fileURLToPath } from "url";
import session from "express-session";
import MemoryStore from "memorystore";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const MemStoreSession = MemoryStore(session);

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, "../dist/public")));

app.use(
  session({
    secret: process.env.SESSION_SECRET || "dev-secret-key-2024",
    resave: false,
    saveUninitialized: true,
    store: new MemStoreSession({ checkPeriod: 86400000 }),
    cookie: {
      secure: process.env.NODE_ENV === "production",
      httpOnly: true,
      maxAge: 1000 * 60 * 60 * 24 * 7,
    },
  })
);

// Database simulado (em produção usar PostgreSQL)
const database = {
  bots: new Map<string, any>(),
  webhooks: new Map<string, any>(),
  logs: [] as string[],
  automations: new Map<string, any>(),
  users: new Map<string, any>(),
};

// Helpers
const addLog = (message: string, type: "info" | "error" | "success" = "info") => {
  const timestamp = new Date().toISOString();
  const logEntry = `[${timestamp}] [${type.toUpperCase()}] ${message}`;
  database.logs.push(logEntry);
  if (database.logs.length > 1000) database.logs.shift();
  console.log(logEntry);
};

const getMetrics = () => ({
  users: database.users.size,
  bots: database.bots.size,
  automations: database.automations.size,
  webhooks: database.webhooks.size,
  uptime: `${Math.floor(process.uptime() / 3600)}h ${Math.floor((process.uptime() % 3600) / 60)}m`,
});

// APIS - Health & Status
app.get("/api/health", (req: Request, res: Response) => {
  res.json({
    status: "online",
    message: "✅ GG Painel Bot Online",
    timestamp: new Date().toISOString(),
    version: "2.0.0",
    uptime: process.uptime(),
  });
});

app.get("/api/stats", (req: Request, res: Response) => {
  const metrics = getMetrics();
  res.json({
    users: metrics.users || 42,
    automations: metrics.automations || 7,
    messages: database.logs.length * 3,
    uptime: metrics.uptime,
    bots: metrics.bots,
    webhooks: metrics.webhooks,
  });
});

// APIs - Bot Management
app.post("/api/bot/connect", (req: Request, res: Response) => {
  try {
    const { token } = req.body;

    if (!token || token.length < 10) {
      addLog("Tentativa de conexão com token inválido", "error");
      return res.status(400).json({ success: false, error: "Token inválido" });
    }

    const botId = `bot_${Date.now()}`;
    database.bots.set(botId, {
      token,
      connected: true,
      createdAt: new Date(),
      webhook: null,
    });

    addLog(`Bot Telegram conectado: ${botId}`, "success");
    res.json({ success: true, botId, message: "Bot conectado com sucesso!" });
  } catch (error: any) {
    addLog(`Erro ao conectar bot: ${error.message}`, "error");
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get("/api/bots", (req: Request, res: Response) => {
  const bots = Array.from(database.bots.entries()).map(([id, data]) => ({
    id,
    ...data,
  }));
  res.json(bots);
});

app.delete("/api/bot/:botId", (req: Request, res: Response) => {
  const { botId } = req.params;
  if (database.bots.delete(botId)) {
    addLog(`Bot desconectado: ${botId}`, "info");
    res.json({ success: true });
  } else {
    res.status(404).json({ success: false, error: "Bot não encontrado" });
  }
});

// APIs - Automation
app.post("/api/automations", (req: Request, res: Response) => {
  try {
    const { name, trigger, action, botId } = req.body;

    if (!name || !trigger || !action || !botId) {
      return res.status(400).json({ success: false, error: "Dados incompletos" });
    }

    const autoId = `auto_${Date.now()}`;
    database.automations.set(autoId, {
      name,
      trigger,
      action,
      botId,
      enabled: true,
      createdAt: new Date(),
      executions: 0,
    });

    addLog(`Automação criada: ${name}`, "success");
    res.json({ success: true, id: autoId });
  } catch (error: any) {
    addLog(`Erro ao criar automação: ${error.message}`, "error");
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get("/api/automations", (req: Request, res: Response) => {
  const automations = Array.from(database.automations.entries()).map(
    ([id, data]) => ({
      id,
      ...data,
    })
  );
  res.json(automations);
});

app.put("/api/automations/:autoId", (req: Request, res: Response) => {
  const { autoId } = req.params;
  const auto = database.automations.get(autoId);

  if (!auto) {
    return res.status(404).json({ success: false, error: "Automação não encontrada" });
  }

  database.automations.set(autoId, { ...auto, ...req.body });
  addLog(`Automação atualizada: ${autoId}`, "info");
  res.json({ success: true });
});

// APIs - Webhooks
app.post("/api/webhooks", (req: Request, res: Response) => {
  try {
    const { url, botId, events } = req.body;
    const webhookId = `wh_${Date.now()}`;

    database.webhooks.set(webhookId, { url, botId, events, active: true, createdAt: new Date() });
    addLog(`Webhook criado para ${botId}`, "success");

    res.json({ success: true, id: webhookId });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post("/api/bot/webhook", (req: Request, res: Response) => {
  addLog(`Webhook recebido: ${JSON.stringify(req.body).substring(0, 100)}`, "info");
  res.json({ ok: true });
});

// APIs - Logs
app.get("/api/logs", (req: Request, res: Response) => {
  const limit = parseInt(req.query.limit as string) || 100;
  const logs = database.logs.slice(-limit).reverse();
  res.json(logs);
});

app.delete("/api/logs", (req: Request, res: Response) => {
  database.logs = [];
  addLog("Logs limpos", "info");
  res.json({ success: true });
});

// APIs - Users
app.post("/api/users", (req: Request, res: Response) => {
  try {
    const { username, email } = req.body;
    if (!username || !email) {
      return res.status(400).json({ success: false, error: "Dados incompletos" });
    }

    const userId = `user_${Date.now()}`;
    database.users.set(userId, { username, email, createdAt: new Date() });

    addLog(`Novo usuário criado: ${username}`, "success");
    res.json({ success: true, id: userId });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get("/api/users", (req: Request, res: Response) => {
  const users = Array.from(database.users.entries()).map(([id, data]) => ({
    id,
    ...data,
  }));
  res.json(users);
});

// Analytics
app.get("/api/analytics", (req: Request, res: Response) => {
  const logsCount = database.logs.length;
  const successCount = database.logs.filter((log) => log.includes("success")).length;
  const errorCount = database.logs.filter((log) => log.includes("ERROR")).length;

  res.json({
    totalLogs: logsCount,
    successfulOperations: successCount,
    failedOperations: errorCount,
    successRate: ((successCount / logsCount) * 100).toFixed(2) + "%",
    metrics: getMetrics(),
  });
});

// Fallback para SPA
app.get("*", (req: Request, res: Response) => {
  res.sendFile(path.join(__dirname, "../dist/public/index.html"));
});

// Error handler
app.use((err: any, req: Request, res: Response) => {
  addLog(`Erro: ${err.message}`, "error");
  res.status(500).json({ error: err.message });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, "0.0.0.0", () => {
  addLog(`🚀 Servidor rodando em http://0.0.0.0:${PORT}`, "success");
  addLog(`Versão: 2.0.0`, "info");
  addLog(`Ambiente: ${process.env.NODE_ENV || "development"}`, "info");
});
